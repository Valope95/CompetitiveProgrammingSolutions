In case one wanna a structure for his problem-solving uploads, just clone and build over it.
